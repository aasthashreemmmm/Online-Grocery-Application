package com.example.signUpsignIn;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SignUpSignInApplicationTests {

	@Test
	void contextLoads() {
	}

}
