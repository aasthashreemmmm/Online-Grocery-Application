package com.example.signUpsignIn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SignUpSignInApplication {

	public static void main(String[] args) {
		SpringApplication.run(SignUpSignInApplication.class, args);
	}

}
