package com.example.product_api.exception;

public class OrderNotFoundException extends RuntimeException{
	public OrderNotFoundException(Long id) {
		super("Could not found product with id "+ id);
	}
}

