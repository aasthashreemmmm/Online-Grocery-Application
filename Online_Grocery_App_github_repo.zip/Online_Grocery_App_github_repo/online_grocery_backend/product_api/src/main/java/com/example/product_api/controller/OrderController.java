package com.example.product_api.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.product_api.entity.CartProduct;
import com.example.product_api.entity.Order;
import com.example.product_api.exception.OrderNotFoundException;
import com.example.product_api.repository.OrderRepository;

@RestController
@CrossOrigin("http://localhost:3000")
@RequestMapping("/api/orders")
public class OrderController{
    @Autowired
    private OrderRepository orderRepository;

    @PostMapping("/newOrder")
    public ResponseEntity<Order> newOrder(@RequestBody Order newOrder) {
        Order createdOrder = orderRepository.save(newOrder);
        return ResponseEntity.ok(createdOrder);
    }

    @GetMapping("/")
    public List<Order> getAllOrders() {
        return orderRepository.findAll();
    }

    @GetMapping("/{id}")
    public Order getOrderById(@PathVariable Long id) {
        return orderRepository.findById(id)
                .orElseThrow(() -> new OrderNotFoundException(id));
    }

    @PutMapping("/{id}")
    public Order updateOrder(@RequestBody Order newOrder, @PathVariable Long id) {
        return orderRepository.findById(id)
                .map(order -> {
                    order.setCustomerId(newOrder.getCustomerId());
                    order.setOrderDate(newOrder.getOrderDate());
                    order.setDeliveryAddress(newOrder.getDeliveryAddress());
                    order.setPaymentMethod(newOrder.getPaymentMethod());
                    order.setTotalAmount(newOrder.getTotalAmount());
                    return orderRepository.save(order);
                })
                .orElseThrow(() -> new OrderNotFoundException(id));
    }

    @DeleteMapping("/{id}")
    public String deleteOrder(@PathVariable Long id) {
        if (!orderRepository.existsById(id)) {
            throw new OrderNotFoundException(id);
        }
        orderRepository.deleteById(id);
        return "Order with id " + id + " has been deleted successfully";
    }

    @GetMapping("/{orderId}/products")
    public ResponseEntity<List<CartProduct>> getOrderProducts(@PathVariable Long orderId) {
        try {
            Order order = getOrderById(orderId);
            List<CartProduct> products = (List<CartProduct>) order.getProducts();
            return ResponseEntity.ok(products);
        } catch (OrderNotFoundException e) {
            return ResponseEntity.notFound().build();
        }
    }

}
