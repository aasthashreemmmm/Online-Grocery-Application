package com.example.product_api.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.product_api.entity.Order;

public interface OrderRepository extends JpaRepository<Order, Long>{
}
