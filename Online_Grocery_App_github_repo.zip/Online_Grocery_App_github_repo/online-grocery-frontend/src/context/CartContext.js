import React, { createContext, useState } from "react";

export const CartContext = createContext();

export const CartProvider = ({ children }) => {
  const [cartItems, setCartItems] = useState([]);

  const addToCart = (product) => {
    const existingItem = cartItems.find((item) => item.id === product.id);

    if (existingItem) {
      const updatedCartItems = cartItems.map((item) =>
        item.id === product.id
          ? {
              ...item,
              cartQuantity: item.cartQuantity + 1,
              price: product.price * 1,
            }
          : item
      );
      setCartItems(updatedCartItems);
    } else {
      setCartItems([
        ...cartItems,
        { ...product, cartQuantity: 1, price: product.price },
      ]);
    }
  };

  const increaseQuantity = (itemId) => {
    const updatedCartItems = cartItems.map((item) =>
      item.id === itemId
        ? {
            ...item,
            cartQuantity: item.cartQuantity + 1,
            price: item.price * 1,
          }
        : item
    );
    setCartItems(updatedCartItems);
  };

  const decreaseQuantity = (itemId) => {
    const updatedCartItems = cartItems.map((item) =>
      item.id === itemId && item.cartQuantity > 1
        ? {
            ...item,
            cartQuantity: item.cartQuantity - 1,
            price: item.price * 1,
          }
        : item
    );
    setCartItems(updatedCartItems);
  };

  const removeItem = (itemId) => {
    const updatedCartItems = cartItems.filter((item) => item.id !== itemId);
    setCartItems(updatedCartItems);
  };

  const removeAllItems = () => {
    setCartItems([]);
  };

  return (
    <CartContext.Provider
      value={{
        cartItems,
        addToCart,
        removeItem,
        removeAllItems,
        increaseQuantity,
        decreaseQuantity,
      }}
    >
      {children}
    </CartContext.Provider>
  );
};
