import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Login from "./components/login";
import Signup from "./components/signup";
import Admin from "./components/admin";
import Products from "./components/product/products";
import AddProduct from "./components/product/addProduct";
import Home from "./components/home";
import Checkout from "./components/cart/checkout";
import { CartProvider } from "./context/CartContext";
import OrderPlaced from "./components/cart/orderPlaced";
import Orders from "./components/cart/orders";


function App() {
  return (
    <BrowserRouter>
      <CartProvider>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<Signup />} />
          <Route path="/admin" element={<Admin />} />
          <Route path="/admin/products" element={<Products />} />
          <Route path="/admin/products/add-product" element={<AddProduct />} />
          <Route path="/checkout" element={<Checkout />} />
          <Route path="/order-placed" element={<OrderPlaced />} />
          <Route path="/admin/orders" element={<Orders />} />
        </Routes>
      </CartProvider>
    </BrowserRouter>
  );
}

export default App;
