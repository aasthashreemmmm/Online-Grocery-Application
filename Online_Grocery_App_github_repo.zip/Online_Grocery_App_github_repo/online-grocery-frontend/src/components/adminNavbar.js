import React from "react";
import { Link,NavLink } from "react-router-dom";

function AdminNavbar() {
  return (
    <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
      <div className="container">
        <h4 color="white" font-family="Arial">KiranaEasy</h4>
        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav">
            <li className="nav-item">
              <NavLink
                className="nav-link"
                activeClassName="active"
                exact
                to="/admin">
               Customers
              </NavLink>
            </li>
            <li className="nav-item">
              <NavLink
                className="nav-link"
                activeClassName="active"
                exact
                to="/admin/products"
              >
                Products
              </NavLink>
            </li>
            <li className="nav-item">
              <NavLink
                className="nav-link"
                activeClassName="active"
                exact
                to="/admin/orders">
                Orders
              </NavLink>
            </li>
            <Link exact to="/" type="submit" value="logout" className="btn btn-info">Home
              </Link>
          </ul>
        </div>
      </div>
    </nav>
  );
}

export default AdminNavbar;
