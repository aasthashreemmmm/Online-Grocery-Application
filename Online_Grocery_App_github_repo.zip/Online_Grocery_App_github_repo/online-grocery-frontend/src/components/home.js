import React, { useContext, useEffect, useState } from "react";
import axios from "axios";
import Navbar from "./navbar.js";
import "./css/home.css";
import { CartContext } from "../context/CartContext.js";

function Home() {
  const [products, setProducts] = useState([]);
  const { cartItems, addToCart, removeItem } = useContext(CartContext);
  const [searchResults, setSearchResults] = useState([]);
  const [noResults, setNoResults] = useState(false);

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const response = await axios.get("http://localhost:9011/api/product/products");
        const data = response.data;
        setProducts(data);
      } catch (error) {
        console.error("Error fetching products:", error);
      }
    };

    fetchProducts();
  }, []);

  const handleSearch = (searchQuery) => {
    if (searchQuery.trim() === "") {
      // Empty search query, reset search results
      setSearchResults([]);
      setNoResults(false);
    } else {
      // Filter products based on search query
      const filteredProducts = products.filter((product) => {
        const { name, brand, category } = product;
        const lowerCaseQuery = searchQuery.toLowerCase();
        return (
          name.toLowerCase().includes(lowerCaseQuery) ||
          brand.toLowerCase().includes(lowerCaseQuery) ||
          category.toLowerCase().includes(lowerCaseQuery)
        );
      });

      setSearchResults(filteredProducts);
      setNoResults(filteredProducts.length === 0);
    }
  };

  // Determine the list of products to display based on search results
  const productList = searchResults.length > 0 ? searchResults : products;

  const totalQuantity = cartItems.reduce((total, item) => total + item.cartQuantity, 0);

  return (
    <div className="main" style={{ 
      backgroundImage: `url("https://www.rd.com/wp-content/uploads/2022/08/GettyImages-1157106624.jpg")` 
    }}>
      <Navbar cartItems={cartItems} removeItem={removeItem} handleSearch={handleSearch} />
      <div align="center" className="container mt-4">
        <h2 align="center">Happy Grocery shopping !</h2><br/>
        <div align="center" class="home" id="home">
        <div class="content">
            <h1>India Ka Apna E-Grocery Bazaar</h1>    
            <h3>SHOP... PAY...GET...REPEAT !!</h3>      
        </div>
     </div> <br/>
        <p className="cart-items-count">Cart Items: {totalQuantity}</p>
        {noResults ? (
          <p>No Results Found</p>
        )
         : (
          <div className="row mt-4">
            {productList.map((product) => (
              <div className="col-md-4" key={product.id}>
                <div  className="card mb-3">
                  <img 
                    src={product.imageUrl}
                    className="card-img-top small-image"
                    alt={product.name}
                  />
                  <div className="card-body">
                    <h5 className="card-title">Name: {product.name}</h5>
                    <p className="card-text brand">Brand: {product.brand}</p>
                    <p className="card-text quantity">Quantity: {product.quantity}</p>
                    <p className="card-text price">&#x20B9;{product.price}</p>
                    <button className="btn btn-primary" onClick={() => addToCart(product)}>
                      Add to Cart
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export default Home;
