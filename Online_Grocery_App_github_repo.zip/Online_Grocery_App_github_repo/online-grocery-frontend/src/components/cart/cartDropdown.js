import React from "react";
import { FaTrash } from "react-icons/fa";
import "./cart-dropdown.css";

function CartDropdown({ cartItems, removeItem }) {
  const handleRemoveItem = (itemId) => {
    removeItem(itemId);
  };

  return (
    <div className="cart-dropdown">
      {cartItems.length ? (
        <ul className="cart-items">
          {cartItems.map((item) => (
            <li key={item.id} className="cart-item">
              <img src={item.imageUrl} alt={item.name} className="cart-item-image" />
              <div className="cart-item-details">
                <span className="cart-item-name">{item.name}</span>
                <span className="cart-item-quantity"> x {item.cartQuantity}</span>
              </div>
              <span className="cart-item-price">&#x20B9;{item.price * item.cartQuantity}</span>
              <button className="remove-button" onClick={() => handleRemoveItem(item.id)}>
                <FaTrash className="remove-icon" />
              </button>
            </li>
          ))}
        </ul>
      ) : (
        <span className="empty-message">Your cart is empty.</span>
      )}
    </div>
  );
}

export default CartDropdown;
