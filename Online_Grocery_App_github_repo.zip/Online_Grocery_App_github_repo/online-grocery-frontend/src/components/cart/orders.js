import React, { useEffect, useState } from "react";
import axios from "axios";
import { RiDeleteBin6Line } from "react-icons/ri";
import { Dropdown } from "react-bootstrap";
import AdminNavbar from "../adminNavbar";

function Orders() {
  const [orders, setOrders] = useState([]);

  useEffect(() => {
    // Fetch orders from the database using Axios
    axios
      .get("http://localhost:9011/api/orders/")
      .then((response) => {
        setOrders(response.data);
      })
      .catch((error) => {
        console.error("Error fetching orders:", error);
      });
  }, []);

  const deleteOrder = (orderId) => {
    // Delete order from the database using Axios
    axios
      .delete(`http://localhost:9011/api/orders/${orderId}`)
      .then(() => {
        // Remove the deleted order from the state
        setOrders(orders.filter((order) => order.orderId !== orderId));
      })
      .catch((error) => {
        console.error("Error deleting order:", error);
      });
  };

  return (
    <div>
      <AdminNavbar />
      <div className="container"> <br/>
        <h2>Orders</h2>
        <table className="table">
          <thead>
            <tr>
              <th>Order ID</th>
              <th>Customer ID</th>
              <th>Order Date</th>
              <th>Delivery Address</th>
              <th>Payment Method</th>
              <th>Total Amount</th>
              <th>Products</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {orders.map((order) => (
              <tr key={order.orderId}>
                <td>{order.orderId}</td>
                <td>{order.customerId}</td>
                <td>{order.orderDate}</td>
                <td>{order.deliveryAddress}</td>
                <td>{order.paymentMethod}</td>
                <td>{order.totalAmount}</td>
                <td>
                  <Dropdown>
                    <Dropdown.Toggle variant="primary" id="dropdown-products">
                      View Products
                    </Dropdown.Toggle>
                    <Dropdown.Menu>
                      {order.products.map((product) => (
                        <Dropdown.Item
                          key={product.productId}
                          href="#"
                        >{`${product.name} - ${product.cartQuantity}`}</Dropdown.Item>
                      ))}
                    </Dropdown.Menu>
                  </Dropdown>
                </td>
                <td>
                  <button
                    className="btn btn-danger"
                    onClick={() => deleteOrder(order.orderId)}
                  >
                    <RiDeleteBin6Line />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default Orders;
