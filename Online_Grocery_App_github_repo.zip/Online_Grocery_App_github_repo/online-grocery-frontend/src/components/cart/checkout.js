import React, { useContext, useState } from "react";
import { CartContext } from "../../context/CartContext";
import "./checkout.css";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { RiSubtractLine, RiAddLine, RiDeleteBinLine } from "react-icons/ri";

function Checkout() {
  const {
    cartItems,
    removeAllItems,
    removeItem,
    increaseQuantity,
    decreaseQuantity,
  } = useContext(CartContext);
  const [email, setEmail] = useState("");
  const [address, setAddress] = useState("");
  const navigate = useNavigate();

  // Calculate the total amount
  const totalAmount = cartItems.reduce(
    (total, item) => total + item.price * item.cartQuantity,
    0
  );

  const handleEmailChange = (e) => {
    setEmail(e.target.value);
  };

  const handleAddressChange = (e) => {
    setAddress(e.target.value);
  };

  const checkEmailExists = () => {
    const requestData = {
      email: email,
    };

    // Make an API request to check if the email exists
    return axios
      .post("http://localhost:9010/api/auth/users/check-email", requestData)
      .then((response) => response.data)
      .catch((error) => {
        console.error("Error checking email existence:", error);
        throw error;
      });
  };

  const placeOrder = () => {
    if (address.trim() === "") {
      alert(
        "Delivery address cannot be empty. Please provide a valid address."
      );
      return;
    }

    // Check if the email exists
    checkEmailExists()
      .then((emailExists) => {
        if (!emailExists) {
          alert("Email does not exist. Please provide a valid email.");
        } else {
          // Fetch the user ID based on the email
          axios
            .post("http://localhost:9010/api/auth/find-by-email", {
              email: email,
            })
            .then((response) => {
              const user = response.data;
              const userId = user.id; // Assuming the user object has an 'id' field

              // Create the order payload
              const orderPayload = {
                customerId: userId, // Set the customer ID based on the user ID
                orderDate: new Date().toISOString(),
                deliveryAddress: address,
                paymentMethod: "Cash On delivery", // Replace with the selected payment method
                totalAmount: totalAmount,
                products: cartItems.map((item) => ({
                  name: item.name,
                  category: item.category,
                  brand: item.brand,
                  price: item.price,
                  quantity: item.quantity,
                  imageUrl: item.imageUrl,
                  cartQuantity: item.cartQuantity
                })),
              };

              // Make an API request to store the order in the database
              axios
                .post("http://localhost:9011/api/orders/newOrder", orderPayload)
                .then((response) => {
                  // Handle successful order placement
                  console.log("Order placed successfully:", response.data);
                  // Add your logic here for further actions after successful order placement
                  removeAllItems();
                  // Navigate to the "OrderPlaced" page
                  navigate("/order-placed");
                })
                .catch((error) => {
                  console.error("Error placing order:", error);
                  // Handle error while placing the order
                });
            })
            .catch((error) => {
              console.error("Error fetching user ID:", error);
              // Handle error while fetching the user ID
            });
        }
      })
      .catch((error) => {
        // Handle error if the email existence check fails
        console.error("Error checking email existence:", error);
      });
  };

  return (
    <div className="container" style={{ 
      backgroundImage: `url(""https://media.istockphoto.com/id/843469610/photo/supermarket-aisle-blur-abstract-background.jpg?s=612x612&w=0&k=20&c=LxrddR2aIUCoR8k3MKDxQm-gtS8oqpdoJK1DUOzvFx4=")` 
    }}>
      <h2 className="mt-4">Checkout</h2>
      {cartItems.length === 0 ? (
        <p className="mt-4">Your cart is empty.</p>
      ) : (
        <div className="mt-4">
          {cartItems.map((item) => (
            <div className="card mb-3" key={item.id}>
              <div className="row g-0">
                <div className="col-md-4">
                  <img
                    src={item.imageUrl}
                    className="card-img small-image"
                    alt={item.name}
                  />
                </div>
                <div className="col-md-8">
                  <div className="card-body">
                    <h5 className="card-title">{item.name}</h5>
                    <p className="card-text">Quantity: {item.cartQuantity}</p>
                    <p className="card-text">Price: {item.price * item.cartQuantity}</p>
                    <div className="d-flex align-items-center">
                      <button
                        className="btn btn-outline-primary me-2"
                        onClick={() => decreaseQuantity(item.id)}
                      >
                        <RiSubtractLine size={20} />
                      </button>
                      <button
                        className="btn btn-outline-primary me-2"
                        onClick={() => increaseQuantity(item.id)}
                      >
                        <RiAddLine size={20} />
                      </button>
                      <button
                        className="btn btn-outline-danger"
                        onClick={() => removeItem(item.id)}
                      >
                        <RiDeleteBinLine size={20} />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
          <div className="mt-4">
            <h4>Total Amount: {totalAmount}</h4>
            <div className="form-group">
              <label>Email:</label>
              <input
                type="email"
                className="form-control"
                value={email}
                onChange={handleEmailChange}
              />
            </div>
            <div className="form-group">
              <label>Delivery Address:</label>
              <textarea
                className="form-control"
                value={address}
                onChange={handleAddressChange}
              ></textarea>
            </div>
            <button className="btn btn-primary" onClick={placeOrder}>
              Confirm Order
            </button>
          </div><br/>
          <h3>Please pay via cash!</h3>
        </div>
      )}
    </div>
  );
}

export default Checkout;
