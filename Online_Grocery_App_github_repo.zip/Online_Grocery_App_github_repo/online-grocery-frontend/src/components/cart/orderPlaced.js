import React from "react";
import { useNavigate } from "react-router-dom";

function OrderPlaced() {
  const navigate = useNavigate();

  const handleContinueShopping = () => {
    // Navigate to the shopping page
    navigate("/");
  };

  return (
    <div className="container" 
   >
      <h2 className="mt-4">Order confirmed, please wait for delivery boy.</h2>
      <h3 className="mt-4">Delivery will take at most 60 minutes!</h3>
      <p className="lead">Meanwhile, place another order?</p>
      <button className="btn btn-primary" onClick={handleContinueShopping}>
        Continue Shopping
      </button>
    </div>
  );
}

export default OrderPlaced;
