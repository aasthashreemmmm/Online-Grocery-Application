import React, { useState, useContext } from "react";
import { Link, useNavigate } from "react-router-dom";
import CartDropdown from "./cart/cartDropdown";
import { RiSearchLine, RiUserAddLine, RiLoginCircleLine } from "react-icons/ri";
import "./css/navbar.css";
import { CartContext } from "../context/CartContext";

function Navbar({ removeItem, handleSearch }) {
  const { cartItems } = useContext(CartContext);
  const navigate = useNavigate();
  const [isCartOpen, setCartOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  const handleCartToggle = () => {
    setCartOpen(!isCartOpen);
  };

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    handleSearch(searchQuery);
  };

  const hasItemsInCart = cartItems.length > 0;

  const handleCheckout = () => {
    navigate("/checkout", { state: { cartItems } });
  };

  const handleSignup = () => {
    navigate("/signup");
  };

  const handleLogin = () => {
    navigate("/login");
  };

  return (
    <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
      <div className="container">
        <Link className="navbar-brand" to="/">
          KiranaEasy
        </Link>
        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNav"
          aria-controls="navbarNav"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav flex-grow-1">
            <li className="nav-item">
              <form className="d-flex" onSubmit={handleSearchSubmit}>
                <input
                  className="form-control me-2"
                  type="search"
                  placeholder="Search some product..."
                  aria-label="Search"
                  style={{ maxWidth: "300px" }}
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
                <button className="btn btn-outline-light" type="submit">
                  <RiSearchLine className="search-icon" />
                </button>
              </form>
            </li>
          </ul>
          <ul className="navbar-nav">
            <li className="nav-item dropdown">
              <button
                className="nav-link dropdown-toggle btn btn-link cart-button"
                onClick={handleCartToggle}
              >
                Cart
              </button>
              {isCartOpen && <CartDropdown cartItems={cartItems} removeItem={removeItem} />}
            </li>
            {hasItemsInCart && (
              <li className="nav-item">
                <button className="btn btn-primary mx-2" onClick={handleCheckout}>
                  Checkout
                </button>
              </li>
            )}
            <li className="nav-item">
              <button className="btn btn-outline-light" onClick={handleSignup}>
                <RiUserAddLine className="signup-icon" />
              </button>
            </li>
            <li className="nav-item">
              <button className="btn btn-outline-light" onClick={handleLogin}>
                <RiLoginCircleLine className="signin-icon" />
              </button>
            </li>
            <li className="nav-item">
              <Link exact to="/login" type="submit" value="logout" className="btn btn-info">LOGOUT
              </Link>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  );
}

export default Navbar;
