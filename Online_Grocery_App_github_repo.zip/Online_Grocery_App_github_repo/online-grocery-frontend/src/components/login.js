import axios from "axios";
import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";

function Login() {
  let navigate = useNavigate();
  const [user, setUser] = useState({
    usernameOrEmail: "",
    password: "",
  });

  const { usernameOrEmail, password } = user;

  const onInputChange = (e) => {
    setUser({ ...user, [e.target.name]: e.target.value });
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    if (!usernameOrEmail || !password) {
      alert("Please fill in all fields");
      return;
    }
    const response = await axios.post("http://localhost:9010/api/auth/signin", user);
    console.log("Response:", response.data);
    navigate("/");
  };
  return (
    <div className="container">
      <div className="row">
        <div className="col-md-6 offset-md-3 border rounded p-4 mt-2 shadow">
          <h2 className="text-center m-4">Login</h2>
          <form onSubmit={(e) => onSubmit(e)}>
            <div className="mb-3">
              <label htmlFor="UsernameOrEmail" className="form-label">
                E-mail
              </label>
              <input
                type={"email"}
                className="form-control"
                placeholder="Enter your e-mail address"
                name="usernameOrEmail"
                value={usernameOrEmail}
                onChange={(e) => onInputChange(e)} required
              />
            </div>
            <div className="mb-3">
              <label htmlFor="Password" className="form-label">
                Password
              </label>
              <input
                type={"password"}
                className="form-control"
                placeholder="Create your password"
                name="password"
                value={password}
                onChange={(e) => onInputChange(e)} required
              />
            </div>
            <button type="submit" className="btn btn-outline-primary">
              Submit
            </button>
            <Link exact to="/admin"type="submit" className="btn btn-outline-primary" >
              Go to Admin panel
            </Link>
          </form>
        </div>
      </div>
    </div>
  );
}

export default Login;
